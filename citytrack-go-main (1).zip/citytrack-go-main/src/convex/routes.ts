import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getCurrentUser } from "./users";

// Get all active routes
export const getActiveRoutes = query({
  args: {},
  handler: async (ctx) => {
    const routes = await ctx.db
      .query("busRoutes")
      .withIndex("isActive", (q) => q.eq("isActive", true))
      .collect();

    // Get stop details for each route
    const routesWithStops = await Promise.all(
      routes.map(async (route) => {
        const stops = await Promise.all(
          route.stops.map(async (stopId) => {
            return await ctx.db.get(stopId);
          })
        );
        return {
          ...route,
          stopsDetails: stops.filter(Boolean),
        };
      })
    );

    return routesWithStops;
  },
});

// Get route by ID
export const getRouteById = query({
  args: { routeId: v.id("busRoutes") },
  handler: async (ctx, args) => {
    const route = await ctx.db.get(args.routeId);
    if (!route) return null;

    const stops = await Promise.all(
      route.stops.map(async (stopId) => {
        return await ctx.db.get(stopId);
      })
    );

    return {
      ...route,
      stopsDetails: stops.filter(Boolean),
    };
  },
});

// Search routes
export const searchRoutes = query({
  args: { searchTerm: v.string() },
  handler: async (ctx, args) => {
    const routes = await ctx.db
      .query("busRoutes")
      .withIndex("isActive", (q) => q.eq("isActive", true))
      .collect();

    // Handle optional description safely
    const term = args.searchTerm.toLowerCase();
    const filteredRoutes = routes.filter((route) => {
      const name = route.routeName.toLowerCase();
      const number = route.routeNumber.toLowerCase();
      const desc = (route.description || "").toLowerCase();
      return name.includes(term) || number.includes(term) || desc.includes(term);
    });

    return filteredRoutes;
  },
});

// Create new route
export const createRoute = mutation({
  args: {
    routeNumber: v.string(),
    routeName: v.string(),
    description: v.string(),
    fare: v.number(),
    estimatedDuration: v.number(),
    stops: v.array(v.id("busStops")),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user || user.role !== "admin") {
      throw new Error("Unauthorized");
    }

    return await ctx.db.insert("busRoutes", {
      ...args,
      isActive: true,
    });
  },
});