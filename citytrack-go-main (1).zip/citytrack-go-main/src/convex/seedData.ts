import { mutation } from "./_generated/server";

// Seed initial data for the application
export const seedInitialData = mutation({
  args: {},
  handler: async (ctx) => {
    // Check if data already exists
    const existingStops = await ctx.db.query("busStops").collect();
    if (existingStops.length > 0) {
      return { message: "Data already exists" };
    }

    // Create admin user
    const adminUser = await ctx.db.insert("users", {
      name: "System Administrator", 
      email: "admin@punjab.gov.in",
      role: "admin",
    });

    // Create demo driver user
    const driverUser = await ctx.db.insert("users", {
      name: "Rajesh Kumar",
      phoneNumber: "+919876543210",
      role: "driver",
      isAnonymous: true,
    });

    // Create bus stops
    const busStops = [
      {
        name: "City Center",
        nameHindi: "शहर केंद्र",
        namePunjabi: "ਸ਼ਹਿਰ ਕੇਂਦਰ",
        latitude: 30.7333,
        longitude: 76.7794,
        address: "Sector 17, Chandigarh",
        isActive: true,
      },
      {
        name: "Railway Station",
        nameHindi: "रेलवे स्टेशन",
        namePunjabi: "ਰੇਲਵੇ ਸਟੇਸ਼ਨ",
        latitude: 30.7046,
        longitude: 76.8070,
        address: "Chandigarh Railway Station",
        isActive: true,
      },
      {
        name: "ISBT Sector 43",
        nameHindi: "आईएसबीटी सेक्टर 43",
        namePunjabi: "ਆਈਐਸਬੀਟੀ ਸੈਕਟਰ 43",
        latitude: 30.7194,
        longitude: 76.8103,
        address: "Sector 43, Chandigarh",
        isActive: true,
      },
      {
        name: "PGI Hospital",
        nameHindi: "पीजीआई अस्पताल",
        namePunjabi: "ਪੀਜੀਆਈ ਹਸਪਤਾਲ",
        latitude: 30.7669,
        longitude: 76.7753,
        address: "Sector 12, Chandigarh",
        isActive: true,
      },
      {
        name: "Panjab University",
        nameHindi: "पंजाब विश्वविद्यालय",
        namePunjabi: "ਪੰਜਾਬ ਯੂਨੀਵਰਸਿਟੀ",
        latitude: 30.7608,
        longitude: 76.7747,
        address: "Sector 14, Chandigarh",
        isActive: true,
      },
      {
        name: "Sector 22 Market",
        nameHindi: "सेक्टर 22 बाजार",
        namePunjabi: "ਸੈਕਟਰ 22 ਬਾਜ਼ਾਰ",
        latitude: 30.7267,
        longitude: 76.7516,
        address: "Sector 22, Chandigarh",
        isActive: true,
      },
    ];

    const stopIds = [];
    for (const stop of busStops) {
      const stopId = await ctx.db.insert("busStops", stop);
      stopIds.push(stopId);
    }

    // Create bus routes
    const routes = [
      {
        routeNumber: "Route 1",
        routeName: "City Center - Railway Station",
        description: "Main city route connecting major hubs",
        fare: 15,
        estimatedDuration: 45,
        isActive: true,
        stops: [stopIds[0], stopIds[5], stopIds[1]], // City Center -> Sector 22 -> Railway Station
      },
      {
        routeNumber: "Route 2",
        routeName: "PGI - University Circuit",
        description: "Educational and medical facilities route",
        fare: 12,
        estimatedDuration: 30,
        isActive: true,
        stops: [stopIds[3], stopIds[4], stopIds[0]], // PGI -> University -> City Center
      },
      {
        routeNumber: "Route 3",
        routeName: "ISBT Express",
        description: "Express route to interstate bus terminal",
        fare: 20,
        estimatedDuration: 25,
        isActive: true,
        stops: [stopIds[0], stopIds[2]], // City Center -> ISBT
      },
    ];

    const routeIds = [];
    for (const route of routes) {
      const routeId = await ctx.db.insert("busRoutes", route);
      routeIds.push(routeId);
    }

    // Create buses
    const buses = [
      {
        busNumber: "CH01-2024",
        routeId: routeIds[0],
        driverName: "Rajesh Kumar",
        driverPhone: "+91-9876543210",
        driverUserId: driverUser, // Assign demo driver
        capacity: 40,
        currentLatitude: 30.7333,
        currentLongitude: 76.7794,
        status: "active" as const,
        crowdLevel: "low" as const,
        lastUpdated: Date.now(),
        nextStopId: stopIds[1],
        estimatedArrival: Date.now() + 10 * 60 * 1000, // 10 minutes from now
      },
      {
        busNumber: "CH02-2024",
        routeId: routeIds[1],
        driverName: "Suresh Singh",
        driverPhone: "+91-9876543211",
        capacity: 35,
        currentLatitude: 30.7669,
        currentLongitude: 76.7753,
        status: "active" as const,
        crowdLevel: "moderate" as const,
        lastUpdated: Date.now(),
        nextStopId: stopIds[4],
        estimatedArrival: Date.now() + 5 * 60 * 1000, // 5 minutes from now
      },
      {
        busNumber: "CH03-2024",
        routeId: routeIds[2],
        driverName: "Amit Sharma",
        driverPhone: "+91-9876543212",
        capacity: 50,
        currentLatitude: 30.7194,
        currentLongitude: 76.8103,
        status: "active" as const,
        crowdLevel: "high" as const,
        lastUpdated: Date.now(),
        nextStopId: stopIds[0],
        estimatedArrival: Date.now() + 15 * 60 * 1000, // 15 minutes from now
      },
    ];

    for (const bus of buses) {
      await ctx.db.insert("buses", bus);
    }

    // Create sample community updates
    const updates = [
      {
        title: "Route 1 Delay Notice",
        content: "Due to road construction on Sector 17, Route 1 buses may experience 10-15 minute delays. We apologize for the inconvenience.",
        authorId: adminUser,
        isOfficial: true,
        priority: "high" as const,
        affectedRoutes: [routeIds[0]],
        isActive: true,
      },
      {
        title: "New Bus Added to Route 2",
        content: "We've added an additional bus to Route 2 to reduce waiting times during peak hours.",
        authorId: adminUser,
        isOfficial: true,
        priority: "medium" as const,
        affectedRoutes: [routeIds[1]],
        isActive: true,
      },
    ];

    for (const update of updates) {
      await ctx.db.insert("communityUpdates", update);
    }

    return { 
      message: "Initial data seeded successfully",
      stops: stopIds.length,
      routes: routeIds.length,
      buses: buses.length,
      adminUserId: adminUser,
      driverUserId: driverUser,
    };
  },
});