import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getCurrentUser } from "./users";

// Get active community updates
export const getActiveCommunityUpdates = query({
  args: {},
  handler: async (ctx) => {
    const updates = await ctx.db
      .query("communityUpdates")
      .withIndex("isActive", (q) => q.eq("isActive", true))
      .collect();

    // Sort by priority and creation time
    const sortedUpdates = updates.sort((a, b) => {
      const priorityOrder = { high: 3, medium: 2, low: 1 };
      if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      }
      return b._creationTime - a._creationTime;
    });

    // Get author details
    const updatesWithAuthors = await Promise.all(
      sortedUpdates.map(async (update) => {
        const author = await ctx.db.get(update.authorId);
        return {
          ...update,
          author,
        };
      })
    );

    return updatesWithAuthors;
  },
});

// Create community update
export const createCommunityUpdate = mutation({
  args: {
    title: v.string(),
    content: v.string(),
    priority: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    affectedRoutes: v.optional(v.array(v.id("busRoutes"))),
    expiresAt: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) {
      throw new Error("User must be authenticated");
    }

    const isOfficial = user.role === "admin" || user.role === "authority";

    return await ctx.db.insert("communityUpdates", {
      title: args.title,
      content: args.content,
      authorId: user._id,
      isOfficial,
      priority: args.priority,
      affectedRoutes: args.affectedRoutes,
      isActive: true,
      expiresAt: args.expiresAt,
    });
  },
});
