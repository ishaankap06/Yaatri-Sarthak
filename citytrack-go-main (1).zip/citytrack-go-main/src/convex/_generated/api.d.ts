/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";
import type * as admin from "../admin.js";
import type * as auth_emailOtp from "../auth/emailOtp.js";
import type * as auth from "../auth.js";
import type * as busStops from "../busStops.js";
import type * as buses from "../buses.js";
import type * as communityUpdates from "../communityUpdates.js";
import type * as driver from "../driver.js";
import type * as emergencyAlerts from "../emergencyAlerts.js";
import type * as http from "../http.js";
import type * as phoneOtp from "../phoneOtp.js";
import type * as profile from "../profile.js";
import type * as routes from "../routes.js";
import type * as seedData from "../seedData.js";
import type * as users from "../users.js";

/**
 * A utility for referencing Convex functions in your app's API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
declare const fullApi: ApiFromModules<{
  admin: typeof admin;
  "auth/emailOtp": typeof auth_emailOtp;
  auth: typeof auth;
  busStops: typeof busStops;
  buses: typeof buses;
  communityUpdates: typeof communityUpdates;
  driver: typeof driver;
  emergencyAlerts: typeof emergencyAlerts;
  http: typeof http;
  phoneOtp: typeof phoneOtp;
  profile: typeof profile;
  routes: typeof routes;
  seedData: typeof seedData;
  users: typeof users;
}>;
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;
