import { internalMutation, mutation } from "./_generated/server";
import { v } from "convex/values";
import { internal } from "./_generated/api";

/**
 * Internal: create an OTP entry for a phone
 */
export const createOtp = internalMutation({
  args: {
    phone: v.string(),
    code: v.string(),
    expiresAt: v.number(),
  },
  handler: async (ctx, args) => {
    // Invalidate previous active OTPs for this phone
    const existing = await ctx.db
      .query("phoneOtps")
      .withIndex("by_phone", (q) => q.eq("phone", args.phone))
      .collect();

    for (const row of existing) {
      if (!row.used) {
        await ctx.db.patch(row._id, { used: true });
      }
    }

    const id = await ctx.db.insert("phoneOtps", {
      phone: args.phone,
      code: args.code,
      expiresAt: args.expiresAt,
      used: false,
    });

    return id;
  },
});

function normalizePhone(raw: string): string {
  const trimmed = raw.trim();
  // If already in + format and only digits after +, keep as is
  if (/^\+\d{7,15}$/.test(trimmed)) return trimmed;

  const digitsOnly = trimmed.replace(/\D/g, "");

  // Handle common Indian formats
  if (digitsOnly.length === 10) {
    // Assume Indian local number
    return `+91${digitsOnly}`;
  }
  if (digitsOnly.length === 11 && digitsOnly.startsWith("0")) {
    // Strip leading 0 and assume India
    return `+91${digitsOnly.slice(1)}`;
  }
  if (digitsOnly.length === 12 && digitsOnly.startsWith("91")) {
    return `+${digitsOnly}`;
  }

  // Fallback: if we have digits, try prefixing +
  if (digitsOnly.length >= 7 && digitsOnly.length <= 15) {
    return `+${digitsOnly}`;
  }

  return trimmed;
}

/**
 * Public: request an OTP (returns the code for demo purposes)
 */
export const requestOtp = mutation({
  args: { phone: v.string() },
  handler: async (ctx, args) => {
    const phone = normalizePhone(args.phone);
    if (!/^\+\d{7,15}$/.test(phone)) {
      throw new Error("Enter a valid phone number (you can type 10 digits; we'll format it)");
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = Date.now() + 5 * 60 * 1000; // 5 minutes

    await ctx.runMutation(internal.phoneOtp.createOtp, { phone, code, expiresAt });

    // In production, you'd send the code via SMS.
    // For demo, return the code so the UI can display it.
    return { success: true, code, expiresAt };
  },
});

/**
 * Public: verify OTP
 */
export const verifyOtp = mutation({
  args: { phone: v.string(), code: v.string() },
  handler: async (ctx, args) => {
    const phone = normalizePhone(args.phone);
    const now = Date.now();

    const matches = await ctx.db
      .query("phoneOtps")
      .withIndex("by_phone", (q) => q.eq("phone", phone))
      .collect();

    // Find a valid, not used, not expired matching code
    const latestValid = matches
      .filter((m) => !m.used && m.expiresAt > now && m.code === args.code)
      .sort((a, b) => b._creationTime - a._creationTime)[0];

    if (!latestValid) {
      throw new Error("Invalid or expired code");
    }

    await ctx.db.patch(latestValid._id, { used: true });
    return { success: true };
  },
});