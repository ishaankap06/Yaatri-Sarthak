import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

// User roles
export const ROLES = {
  USER: "user",
  DRIVER: "driver", 
  ADMIN: "admin",
  AUTHORITY: "authority"
} as const;

export default defineSchema({
  // Include Convex Auth tables and indexes required for sign-in to work
  ...authTables,

  users: defineTable({
    name: v.optional(v.string()),
    email: v.optional(v.string()),
    phoneNumber: v.optional(v.string()),
    // Make role optional to accommodate existing users created without a role
    role: v.optional(
      v.union(
        v.literal("user"),
        v.literal("driver"),
        v.literal("admin"),
        v.literal("authority")
      )
    ),
    isAnonymous: v.optional(v.boolean()),
    // Allow existing documents with this auth-provided field
    emailVerificationTime: v.optional(v.number()),
  })
    .index("email", ["email"])
    .index("phoneNumber", ["phoneNumber"])
    .index("role", ["role"]),

  phoneOtps: defineTable({
    phone: v.string(),
    code: v.string(),
    expiresAt: v.number(),
    used: v.boolean(),
  }).index("by_phone", ["phone"]),

  busStops: defineTable({
    name: v.string(),
    nameHindi: v.optional(v.string()),
    namePunjabi: v.optional(v.string()),
    latitude: v.number(),
    longitude: v.number(),
    address: v.string(),
    isActive: v.boolean(),
  }).index("isActive", ["isActive"]),

  busRoutes: defineTable({
    routeNumber: v.string(),
    routeName: v.string(),
    description: v.optional(v.string()),
    fare: v.number(),
    estimatedDuration: v.number(),
    stops: v.array(v.id("busStops")),
    isActive: v.boolean(),
  }).index("isActive", ["isActive"]),

  buses: defineTable({
    busNumber: v.string(),
    routeId: v.id("busRoutes"),
    driverName: v.string(),
    driverPhone: v.string(),
    driverUserId: v.optional(v.id("users")),
    capacity: v.number(),
    currentLatitude: v.number(),
    currentLongitude: v.number(),
    status: v.union(v.literal("active"), v.literal("inactive"), v.literal("maintenance")),
    crowdLevel: v.union(v.literal("low"), v.literal("moderate"), v.literal("high")),
    lastUpdated: v.number(),
    nextStopId: v.optional(v.id("busStops")),
    estimatedArrival: v.optional(v.number()),
  })
    .index("status", ["status"])
    .index("routeId", ["routeId"])
    .index("driverUserId", ["driverUserId"]),

  busTrackingHistory: defineTable({
    busId: v.id("buses"),
    latitude: v.number(),
    longitude: v.number(),
    crowdLevel: v.union(v.literal("low"), v.literal("moderate"), v.literal("high")),
    timestamp: v.number(),
  }).index("busId", ["busId"]),

  emergencyAlerts: defineTable({
    userId: v.id("users"),
    busId: v.optional(v.id("buses")),
    emergencyType: v.union(
      v.literal("medical"),
      v.literal("safety"),
      v.literal("harassment"),
      v.literal("accident"),
      v.literal("other")
    ),
    description: v.optional(v.string()),
    latitude: v.number(),
    longitude: v.number(),
    isResolved: v.boolean(),
    resolvedBy: v.optional(v.id("users")),
    resolvedAt: v.optional(v.number()),
  }).index("isResolved", ["isResolved"]),

  communityUpdates: defineTable({
    title: v.string(),
    content: v.string(),
    authorId: v.id("users"),
    isOfficial: v.boolean(),
    priority: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    affectedRoutes: v.optional(v.array(v.id("busRoutes"))),
    isActive: v.boolean(),
    expiresAt: v.optional(v.number()),
  }).index("isActive", ["isActive"]),
});