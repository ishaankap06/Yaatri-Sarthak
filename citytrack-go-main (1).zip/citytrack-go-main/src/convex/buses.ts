import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getCurrentUser } from "./users";

// Get all active buses
export const getActiveBuses = query({
  args: {},
  handler: async (ctx) => {
    const buses = await ctx.db
      .query("buses")
      .withIndex("status", (q) => q.eq("status", "active"))
      .collect();

    // Get route information for each bus
    const busesWithRoutes = await Promise.all(
      buses.map(async (bus) => {
        const route = await ctx.db.get(bus.routeId);
        return {
          ...bus,
          route,
        };
      })
    );

    return busesWithRoutes;
  },
});

// Get buses by route
export const getBusesByRoute = query({
  args: { routeId: v.id("busRoutes") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("buses")
      .withIndex("routeId", (q) => q.eq("routeId", args.routeId))
      .collect();
  },
});

// Get single bus details
export const getBusDetails = query({
  args: { busId: v.id("buses") },
  handler: async (ctx, args) => {
    const bus = await ctx.db.get(args.busId);
    if (!bus) return null;

    const route = await ctx.db.get(bus.routeId);
    const nextStop = bus.nextStopId ? await ctx.db.get(bus.nextStopId) : null;

    return {
      ...bus,
      route,
      nextStop,
    };
  },
});

// Update bus location (for simulation)
export const updateBusLocation = mutation({
  args: {
    busId: v.id("buses"),
    latitude: v.number(),
    longitude: v.number(),
    crowdLevel: v.union(v.literal("low"), v.literal("moderate"), v.literal("high")),
    nextStopId: v.optional(v.id("busStops")),
    estimatedArrival: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user || (user.role !== "admin" && user.role !== "authority")) {
      throw new Error("Unauthorized");
    }

    await ctx.db.patch(args.busId, {
      currentLatitude: args.latitude,
      currentLongitude: args.longitude,
      crowdLevel: args.crowdLevel,
      lastUpdated: Date.now(),
      nextStopId: args.nextStopId,
      estimatedArrival: args.estimatedArrival,
    });

    // Add to tracking history
    await ctx.db.insert("busTrackingHistory", {
      busId: args.busId,
      latitude: args.latitude,
      longitude: args.longitude,
      crowdLevel: args.crowdLevel,
      timestamp: Date.now(),
    });

    return { success: true };
  },
});

// Create new bus
export const createBus = mutation({
  args: {
    busNumber: v.string(),
    routeId: v.id("busRoutes"),
    driverName: v.string(),
    driverPhone: v.string(),
    capacity: v.number(),
    currentLatitude: v.number(),
    currentLongitude: v.number(),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user || user.role !== "admin") {
      throw new Error("Unauthorized");
    }

    return await ctx.db.insert("buses", {
      ...args,
      status: "active",
      crowdLevel: "low",
      lastUpdated: Date.now(),
    });
  },
});
