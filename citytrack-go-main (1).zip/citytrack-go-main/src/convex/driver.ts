import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getCurrentUser } from "./users";

// Get driver profile
export const myProfile = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) {
      throw new Error("Not authenticated");
    }

    if (user.role !== "driver") {
      return { 
        ...user, 
        isDriver: false,
        message: "Access restricted to drivers only" 
      };
    }

    return { 
      ...user, 
      isDriver: true 
    };
  },
});

// Get assigned buses for current driver
export const myAssignedBuses = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user || user.role !== "driver") {
      throw new Error("Unauthorized");
    }

    const buses = await ctx.db
      .query("buses")
      .withIndex("driverUserId", (q) => q.eq("driverUserId", user._id))
      .collect();

    // Get route information for each bus
    const busesWithRoutes = await Promise.all(
      buses.map(async (bus) => {
        const route = await ctx.db.get(bus.routeId);
        return {
          ...bus,
          route,
        };
      })
    );

    // Sort by last updated descending
    return busesWithRoutes.sort((a, b) => b.lastUpdated - a.lastUpdated);
  },
});

// Start shift (placeholder for future session tracking)
export const startShift = mutation({
  args: { busId: v.id("buses") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user || user.role !== "driver") {
      throw new Error("Unauthorized");
    }

    // Verify this driver is assigned to this bus
    const bus = await ctx.db.get(args.busId);
    if (!bus || bus.driverUserId !== user._id) {
      throw new Error("Not assigned to this bus");
    }

    return { success: true, message: "Shift started" };
  },
});

// Update bus telemetry
export const updateBusTelemetry = mutation({
  args: {
    busId: v.id("buses"),
    latitude: v.number(),
    longitude: v.number(),
    crowdLevel: v.optional(v.union(v.literal("low"), v.literal("moderate"), v.literal("high"))),
    nextStopId: v.optional(v.id("busStops")),
    estimatedArrival: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) {
      throw new Error("Not authenticated");
    }

    // Verify this driver is assigned to this bus or user is admin
    const bus = await ctx.db.get(args.busId);
    if (!bus) {
      throw new Error("Bus not found");
    }

    const isAuthorized = 
      bus.driverUserId === user._id || 
      user.role === "admin" || 
      user.role === "authority";

    if (!isAuthorized) {
      throw new Error("Not authorized to update this bus");
    }

    // Update bus location and telemetry
    const updateData: any = {
      currentLatitude: args.latitude,
      currentLongitude: args.longitude,
      lastUpdated: Date.now(),
    };

    if (args.crowdLevel) {
      updateData.crowdLevel = args.crowdLevel;
    }
    if (args.nextStopId) {
      updateData.nextStopId = args.nextStopId;
    }
    if (args.estimatedArrival) {
      updateData.estimatedArrival = args.estimatedArrival;
    }

    await ctx.db.patch(args.busId, updateData);

    // Add to tracking history
    await ctx.db.insert("busTrackingHistory", {
      busId: args.busId,
      latitude: args.latitude,
      longitude: args.longitude,
      crowdLevel: args.crowdLevel || bus.crowdLevel,
      timestamp: Date.now(),
    });

    return { success: true };
  },
});

// End shift (placeholder)
export const endShift = mutation({
  args: { busId: v.id("buses") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user || user.role !== "driver") {
      throw new Error("Unauthorized");
    }

    // Verify this driver is assigned to this bus
    const bus = await ctx.db.get(args.busId);
    if (!bus || bus.driverUserId !== user._id) {
      throw new Error("Not assigned to this bus");
    }

    return { success: true, message: "Shift ended" };
  },
});
