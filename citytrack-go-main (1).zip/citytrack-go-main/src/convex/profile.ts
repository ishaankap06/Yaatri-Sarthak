import { mutation } from "./_generated/server";
import { v } from "convex/values";
import { getCurrentUser } from "./users";

/**
 * Link a verified phone number to the currently authenticated user
 */
export const linkPhoneToCurrentUser = mutation({
  args: { phone: v.string() },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) {
      throw new Error("Not authenticated");
    }

    const phone = args.phone.trim();
    if (!/^\+?\d{7,15}$/.test(phone)) {
      throw new Error("Enter a valid phone number including country code");
    }

    await ctx.db.patch(user._id, { phoneNumber: phone });
    return { success: true };
  },
});
