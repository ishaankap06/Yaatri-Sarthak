import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getCurrentUser } from "./users";

// Add driver by phone number
export const addDriverByPhone = mutation({
  args: { 
    phone: v.string(), 
    name: v.optional(v.string()) 
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user || (user.role !== "admin" && user.role !== "authority")) {
      throw new Error("Unauthorized");
    }

    const phone = args.phone.trim();
    if (!/^\+?\d{7,15}$/.test(phone)) {
      throw new Error("Invalid phone number format");
    }

    // Check if user already exists
    const existingUser = await ctx.db
      .query("users")
      .withIndex("phoneNumber", (q) => q.eq("phoneNumber", phone))
      .unique();

    if (existingUser) {
      // Update existing user to driver role
      await ctx.db.patch(existingUser._id, { 
        role: "driver",
        name: args.name || existingUser.name
      });
      return { userId: existingUser._id, message: "User updated to driver role" };
    } else {
      // Create new driver user
      const userId = await ctx.db.insert("users", {
        phoneNumber: phone,
        name: args.name,
        role: "driver",
        isAnonymous: true,
      });
      return { userId, message: "New driver created" };
    }
  },
});

// Remove driver role
export const removeDriverRole = mutation({
  args: { phone: v.string() },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user || (user.role !== "admin" && user.role !== "authority")) {
      throw new Error("Unauthorized");
    }

    const phone = args.phone.trim();
    const driverUser = await ctx.db
      .query("users")
      .withIndex("phoneNumber", (q) => q.eq("phoneNumber", phone))
      .unique();

    if (!driverUser) {
      throw new Error("Driver not found");
    }

    await ctx.db.patch(driverUser._id, { role: "user" });
    return { success: true };
  },
});

// List all drivers
export const listDrivers = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user || (user.role !== "admin" && user.role !== "authority")) {
      throw new Error("Unauthorized");
    }

    const drivers = await ctx.db
      .query("users")
      .withIndex("role", (q) => q.eq("role", "driver"))
      .collect();

    // Get assigned buses for each driver
    const driversWithBuses = await Promise.all(
      drivers.map(async (driver) => {
        const assignedBuses = await ctx.db
          .query("buses")
          .withIndex("driverUserId", (q) => q.eq("driverUserId", driver._id))
          .collect();

        return {
          ...driver,
          assignedBuses,
        };
      })
    );

    return driversWithBuses;
  },
});

// Assign driver to bus
export const assignDriverToBus = mutation({
  args: { 
    driverUserId: v.id("users"), 
    busId: v.id("buses") 
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user || (user.role !== "admin" && user.role !== "authority")) {
      throw new Error("Unauthorized");
    }

    await ctx.db.patch(args.busId, { 
      driverUserId: args.driverUserId 
    });

    return { success: true };
  },
});

// Admin overview stats
export const adminOverview = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user || (user.role !== "admin" && user.role !== "authority")) {
      throw new Error("Unauthorized");
    }

    const [totalBuses, activeBuses, unresolvedAlerts, drivers] = await Promise.all([
      ctx.db.query("buses").collect(),
      ctx.db.query("buses").withIndex("status", (q) => q.eq("status", "active")).collect(),
      ctx.db.query("emergencyAlerts").withIndex("isResolved", (q) => q.eq("isResolved", false)).collect(),
      ctx.db.query("users").withIndex("role", (q) => q.eq("role", "driver")).collect(),
    ]);

    return {
      totalBuses: totalBuses.length,
      activeBuses: activeBuses.length,
      unresolvedAlerts: unresolvedAlerts.length,
      driversCount: drivers.length,
    };
  },
});

// List unresolved alerts
export const listAlerts = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user || (user.role !== "admin" && user.role !== "authority")) {
      throw new Error("Unauthorized");
    }

    const alerts = await ctx.db
      .query("emergencyAlerts")
      .withIndex("isResolved", (q) => q.eq("isResolved", false))
      .collect();

    // Sort by creation time descending
    const sortedAlerts = alerts.sort((a, b) => b._creationTime - a._creationTime);

    // Get user and bus details
    const alertsWithDetails = await Promise.all(
      sortedAlerts.map(async (alert) => {
        const alertUser = await ctx.db.get(alert.userId);
        const bus = alert.busId ? await ctx.db.get(alert.busId) : null;
        return {
          ...alert,
          user: alertUser,
          bus,
        };
      })
    );

    return alertsWithDetails;
  },
});

// Create community update quickly
export const createCommunityUpdateQuick = mutation({
  args: {
    title: v.string(),
    content: v.string(),
    priority: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    affectedRoutes: v.optional(v.array(v.id("busRoutes"))),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user || (user.role !== "admin" && user.role !== "authority")) {
      throw new Error("Unauthorized");
    }

    return await ctx.db.insert("communityUpdates", {
      title: args.title,
      content: args.content,
      authorId: user._id,
      isOfficial: true,
      priority: args.priority,
      affectedRoutes: args.affectedRoutes,
      isActive: true,
    });
  },
});
