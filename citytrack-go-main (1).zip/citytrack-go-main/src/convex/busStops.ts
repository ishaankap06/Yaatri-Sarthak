import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getCurrentUser } from "./users";

// Get all active bus stops
export const getActiveBusStops = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("busStops")
      .withIndex("isActive", (q) => q.eq("isActive", true))
      .collect();
  },
});

// Search bus stops
export const searchBusStops = query({
  args: { searchTerm: v.string() },
  handler: async (ctx, args) => {
    const stops = await ctx.db
      .query("busStops")
      .withIndex("isActive", (q) => q.eq("isActive", true))
      .collect();

    return stops.filter(
      (stop) =>
        stop.name.toLowerCase().includes(args.searchTerm.toLowerCase()) ||
        stop.address.toLowerCase().includes(args.searchTerm.toLowerCase()) ||
        (stop.nameHindi && stop.nameHindi.includes(args.searchTerm)) ||
        (stop.namePunjabi && stop.namePunjabi.includes(args.searchTerm))
    );
  },
});

// Get bus stop by ID
export const getBusStopById = query({
  args: { stopId: v.id("busStops") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.stopId);
  },
});

// Create new bus stop
export const createBusStop = mutation({
  args: {
    name: v.string(),
    nameHindi: v.optional(v.string()),
    namePunjabi: v.optional(v.string()),
    latitude: v.number(),
    longitude: v.number(),
    address: v.string(),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user || user.role !== "admin") {
      throw new Error("Unauthorized");
    }

    return await ctx.db.insert("busStops", {
      ...args,
      isActive: true,
    });
  },
});
