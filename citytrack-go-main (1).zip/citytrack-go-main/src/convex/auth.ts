// THIS FILE IS READ ONLY. Do not touch this file unless you are correctly adding a new auth provider in accordance to the vly auth documentation

import { convexAuth } from "@convex-dev/auth/server";
import { Anonymous } from "@convex-dev/auth/providers/Anonymous";
// Removed Email OTP provider import
// ... keep existing code (other comments)

export const { auth, signIn, signOut, store, isAuthenticated } = convexAuth({
  // Remove emailOtp from providers to disable email login fully
  providers: [Anonymous],
});