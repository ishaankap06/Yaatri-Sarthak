import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getCurrentUser } from "./users";

// Create emergency alert
export const createEmergencyAlert = mutation({
  args: {
    busId: v.optional(v.id("buses")),
    emergencyType: v.union(
      v.literal("medical"),
      v.literal("safety"),
      v.literal("harassment"),
      v.literal("accident"),
      v.literal("other")
    ),
    description: v.optional(v.string()),
    latitude: v.number(),
    longitude: v.number(),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) {
      throw new Error("User must be authenticated to create emergency alert");
    }

    return await ctx.db.insert("emergencyAlerts", {
      userId: user._id,
      busId: args.busId,
      emergencyType: args.emergencyType,
      description: args.description,
      latitude: args.latitude,
      longitude: args.longitude,
      isResolved: false,
    });
  },
});

// Get active emergency alerts
export const getActiveEmergencyAlerts = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user || (user.role !== "admin" && user.role !== "authority")) {
      throw new Error("Unauthorized");
    }

    const alerts = await ctx.db
      .query("emergencyAlerts")
      .withIndex("isResolved", (q) => q.eq("isResolved", false))
      .collect();

    // Get user and bus details for each alert
    const alertsWithDetails = await Promise.all(
      alerts.map(async (alert) => {
        const alertUser = await ctx.db.get(alert.userId);
        const bus = alert.busId ? await ctx.db.get(alert.busId) : null;
        return {
          ...alert,
          user: alertUser,
          bus,
        };
      })
    );

    return alertsWithDetails;
  },
});

// Resolve emergency alert
export const resolveEmergencyAlert = mutation({
  args: { alertId: v.id("emergencyAlerts") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user || (user.role !== "admin" && user.role !== "authority")) {
      throw new Error("Unauthorized");
    }

    await ctx.db.patch(args.alertId, {
      isResolved: true,
      resolvedBy: user._id,
      resolvedAt: Date.now(),
    });

    return { success: true };
  },
});
