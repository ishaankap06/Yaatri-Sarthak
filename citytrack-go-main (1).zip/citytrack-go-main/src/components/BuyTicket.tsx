import { useMemo, useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { IndianRupee, Ticket, Bus, CalendarClock } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";

type ActiveBus = {
  _id: string;
  busNumber: string;
  capacity: number;
  route?: {
    routeName?: string;
    fare?: number;
    routeNumber?: string;
  };
  currentLatitude?: number;
  currentLongitude?: number;
};

export default function BuyTicket() {
  const buses = useQuery(api.buses.getActiveBuses) as unknown as Array<ActiveBus> | undefined;
  const busStops =
    (useQuery(api.busStops.getActiveBusStops) as unknown as Array<{
      _id: string;
      name: string;
      latitude: number;
      longitude: number;
    }>) || undefined;

  const [selectedBusId, setSelectedBusId] = useState<string>("");
  const [selectedDestinationId, setSelectedDestinationId] = useState<string>("");
  const [qty, setQty] = useState<number>(1);
  const [open, setOpen] = useState(false);
  const [pnr, setPnr] = useState<string>("");

  const selectedBus = useMemo(
    () => (buses || []).find((b) => (b._id as unknown as string) === selectedBusId),
    [buses, selectedBusId]
  );

  const destinationStop = useMemo(
    () => (busStops || []).find((s) => (s._id as unknown as string) === selectedDestinationId),
    [busStops, selectedDestinationId]
  );

  const haversineKm = (lat1?: number, lon1?: number, lat2?: number, lon2?: number) => {
    if (
      typeof lat1 !== "number" ||
      typeof lon1 !== "number" ||
      typeof lat2 !== "number" ||
      typeof lon2 !== "number"
    )
      return null;
    const toRad = (x: number) => (x * Math.PI) / 180;
    const R = 6371;
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const baseRouteFare = selectedBus?.route?.fare ?? 0;
  const estimatedFarePer = useMemo(() => {
    if (!selectedBus || !destinationStop) return baseRouteFare;
    const dist = haversineKm(
      (selectedBus as any).currentLatitude,
      (selectedBus as any).currentLongitude,
      destinationStop.latitude,
      destinationStop.longitude
    );
    if (dist === null) return baseRouteFare;
    const est = Math.max(baseRouteFare, Math.round(baseRouteFare + dist * 1.5));
    return est;
  }, [selectedBus, destinationStop, baseRouteFare]);

  const total = Math.max(1, qty) * (estimatedFarePer || 0);

  const handleBuy = () => {
    if (!selectedBus) {
      toast.error("Please select a bus");
      return;
    }
    if (!selectedDestinationId) {
      toast.error("Please select a destination");
      return;
    }
    if (qty < 1 || qty > 10) {
      toast.error("Quantity must be between 1 and 10");
      return;
    }
    const newPnr = `PT-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
    setPnr(newPnr);
    setOpen(true);
    toast.success("Ticket created (sample)");
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Ticket className="h-5 w-5 text-primary" />
            <span>Buy Ticket</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-medium mb-2 block">Select Bus</label>
              <Select value={selectedBusId} onValueChange={setSelectedBusId}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose an active bus" />
                </SelectTrigger>
                <SelectContent>
                  {(buses || []).map((bus) => (
                    <SelectItem key={bus._id} value={bus._id as unknown as string}>
                      <span className="flex items-center gap-2">
                        🚌🇮🇳 {bus.busNumber}
                        {bus.route?.routeName ? (
                          <span className="text-muted-foreground">• {bus.route.routeName}</span>
                        ) : null}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Destination</label>
              <Select value={selectedDestinationId} onValueChange={setSelectedDestinationId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select destination stop" />
                </SelectTrigger>
                <SelectContent>
                  {(busStops || []).map((s) => (
                    <SelectItem key={s._id} value={s._id as unknown as string}>
                      {s.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Quantity</label>
              <Input
                type="number"
                min={1}
                max={10}
                value={qty}
                onChange={(e) => {
                  const v = parseInt(e.target.value || "1", 10);
                  setQty(Number.isNaN(v) ? 1 : v);
                }}
              />
            </div>
          </div>

          <div className="flex items-center justify-between border rounded-md p-3">
            <div className="flex items-center gap-2 text-muted-foreground">
              <IndianRupee className="h-4 w-4" />
              <span>Fare per ticket</span>
            </div>
            <div className="font-semibold">₹{estimatedFarePer}</div>
          </div>

          <div className="flex items-center justify-between border rounded-md p-3">
            <div className="flex items-center gap-2 text-muted-foreground">
              <IndianRupee className="h-4 w-4" />
              <span>Total</span>
            </div>
            <div className="font-bold text-primary">₹{total}</div>
          </div>

          <div className="flex justify-end">
            <Button onClick={handleBuy} disabled={!selectedBus || !selectedDestinationId}>
              Buy Ticket
            </Button>
          </div>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Ticket className="h-5 w-5 text-primary" />
              Sample Ticket
            </DialogTitle>
            <DialogDescription>Non-transferable, demo-only.</DialogDescription>
          </DialogHeader>

          <div className="border rounded-lg p-4 space-y-3 bg-muted/30">
            <div className="flex items-center justify-between">
              <div className="font-semibold">
                {selectedBus?.route?.routeName || "Selected Route"}
              </div>
              <div className="text-sm text-muted-foreground">
                {selectedBus?.route?.routeNumber}
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Bus className="h-4 w-4" />
                {selectedBus?.busNumber}
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CalendarClock className="h-4 w-4" />
                {new Date().toLocaleString()}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="border rounded-md p-2">
                <div className="text-xs text-muted-foreground">Tickets</div>
                <div className="font-semibold">{qty}</div>
              </div>
              <div className="border rounded-md p-2">
                <div className="text-xs text-muted-foreground">Total Fare</div>
                <div className="font-semibold">₹{total}</div>
              </div>
            </div>

            <div className="border rounded-md p-3 bg-white">
              <div className="text-xs text-muted-foreground">Destination</div>
              <div className="font-semibold">
                {destinationStop?.name || "Not selected"}
              </div>
            </div>

            <div className="border rounded-md p-3 bg-white">
              <div className="text-xs text-muted-foreground">PNR</div>
              <div className="font-mono text-lg font-bold tracking-wider">{pnr}</div>
            </div>

            <div className="text-xs text-muted-foreground">
              • Show this ticket to the conductor. • Valid for this demo session only.
            </div>
          </div>

          <div className="flex justify-end">
            <Button onClick={() => setOpen(false)}>Done</Button>
          </div>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}