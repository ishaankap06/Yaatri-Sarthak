import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { AlertTriangle, Phone } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";

export default function EmergencyButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [emergencyType, setEmergencyType] = useState<string>("");
  const [description, setDescription] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const createAlert = useMutation(api.emergencyAlerts.createEmergencyAlert);

  const emergencyTypes = [
    { value: "medical", label: "Medical Emergency", icon: "🏥" },
    { value: "safety", label: "Safety Concern", icon: "⚠️" },
    { value: "harassment", label: "Harassment", icon: "🚫" },
    { value: "accident", label: "Accident", icon: "🚗" },
    { value: "other", label: "Other", icon: "📞" },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emergencyType) {
      toast.error("Please select an emergency type");
      return;
    }

    setIsSubmitting(true);

    try {
      // Get user's location
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject);
      });

      await createAlert({
        emergencyType: emergencyType as any,
        description: description || undefined,
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
      });

      toast.success("Emergency alert sent successfully! Help is on the way.");
      setIsOpen(false);
      setEmergencyType("");
      setDescription("");
    } catch (error) {
      console.error("Error creating emergency alert:", error);
      toast.error("Failed to send emergency alert. Please try again or call emergency services directly.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Button
            variant="destructive"
            size="lg"
            className="bg-red-600 hover:bg-red-700 text-white font-bold shadow-lg"
          >
            <AlertTriangle className="h-5 w-5 mr-2" />
            SOS Emergency
          </Button>
        </motion.div>
      </DialogTrigger>
      
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2 text-red-600">
            <AlertTriangle className="h-5 w-5" />
            <span>Emergency Alert</span>
          </DialogTitle>
          <DialogDescription>
            This will immediately alert the nearest control center with your location.
            For life-threatening emergencies, call 112 directly.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">
              Emergency Type *
            </label>
            <Select value={emergencyType} onValueChange={setEmergencyType}>
              <SelectTrigger>
                <SelectValue placeholder="Select emergency type" />
              </SelectTrigger>
              <SelectContent>
                {emergencyTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    <span className="flex items-center">
                      <span className="mr-2">{type.icon}</span>
                      {type.label}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">
              Additional Details (Optional)
            </label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the situation briefly..."
              rows={3}
            />
          </div>

          <div className="flex space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsOpen(false)}
              className="flex-1"
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="destructive"
              className="flex-1"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Sending..." : "Send Alert"}
            </Button>
          </div>

          <div className="text-center pt-2 border-t">
            <p className="text-sm text-muted-foreground mb-2">
              For immediate emergency services:
            </p>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => window.open("tel:112")}
              className="text-red-600 border-red-600 hover:bg-red-50"
            >
              <Phone className="h-4 w-4 mr-2" />
              Call 112
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
