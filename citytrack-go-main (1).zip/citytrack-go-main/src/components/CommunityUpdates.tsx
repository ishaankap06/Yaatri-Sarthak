import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Megaphone, Clock, AlertTriangle, Info, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function CommunityUpdates() {
  const updates = useQuery(api.communityUpdates.getActiveCommunityUpdates);

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case "high": return <AlertTriangle className="h-4 w-4" />;
      case "medium": return <Info className="h-4 w-4" />;
      case "low": return <CheckCircle className="h-4 w-4" />;
      default: return <Info className="h-4 w-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800 border-red-200";
      case "medium": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "low": return "bg-green-100 text-green-800 border-green-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const formatTimeAgo = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return "Just now";
  };

  if (!updates) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-32">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Megaphone className="h-5 w-5 text-primary" />
            <span>Live Updates</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {updates.length === 0 ? (
            <div className="text-center py-8">
              <Megaphone className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
              <p className="text-muted-foreground">No updates at the moment</p>
            </div>
          ) : (
            updates.map((update, index) => (
              <motion.div
                key={update._id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="border rounded-lg p-4 space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-2">
                    <Badge 
                      variant="secondary" 
                      className={getPriorityColor(update.priority)}
                    >
                      {getPriorityIcon(update.priority)}
                      <span className="ml-1 capitalize">{update.priority}</span>
                    </Badge>
                    {update.isOfficial && (
                      <Badge variant="default" className="bg-primary">
                        Official
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Clock className="h-3 w-3 mr-1" />
                    {formatTimeAgo(update._creationTime)}
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-base mb-2">{update.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {update.content}
                  </p>
                </div>

                {update.author && (
                  <div className="flex items-center text-xs text-muted-foreground pt-2 border-t">
                    <span>
                      Posted by {update.author.name || "Transport Authority"}
                    </span>
                  </div>
                )}
              </motion.div>
            ))
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
