import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Search, MapPin, Route, Clock, IndianRupee } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function SearchBar() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showResults, setShowResults] = useState(false);
  
  const routes = useQuery(api.routes.searchRoutes, 
    searchTerm.length > 2 ? { searchTerm } : "skip"
  );
  const busStops = useQuery(api.busStops.searchBusStops, 
    searchTerm.length > 2 ? { searchTerm } : "skip"
  );

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.length > 2) {
      setShowResults(true);
    }
  };

  const clearSearch = () => {
    setSearchTerm("");
    setShowResults(false);
  };

  return (
    <div className="relative w-full max-w-2xl mx-auto">
      <form onSubmit={handleSearch} className="relative">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search for bus routes, stops, or destinations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onFocus={() => searchTerm.length > 2 && setShowResults(true)}
            className="pl-10 pr-20 h-12 text-base"
          />
          <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex space-x-1">
            {searchTerm && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={clearSearch}
                className="h-8 px-2"
              >
                Clear
              </Button>
            )}
            <Button type="submit" size="sm" className="h-8">
              Search
            </Button>
          </div>
        </div>
      </form>

      <AnimatePresence>
        {showResults && (searchTerm.length > 2) && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-full mt-2 w-full z-50"
          >
            <Card className="shadow-lg">
              <CardContent className="p-0">
                {/* Routes Results */}
                {routes && routes.length > 0 && (
                  <div className="p-4 border-b">
                    <h3 className="font-semibold text-sm text-muted-foreground mb-3 flex items-center">
                      <Route className="h-4 w-4 mr-2" />
                      Routes
                    </h3>
                    <div className="space-y-2">
                      {routes.slice(0, 3).map((route) => (
                        <motion.div
                          key={route._id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="flex items-center justify-between p-3 hover:bg-muted/50 rounded-lg cursor-pointer transition-colors"
                        >
                          <div>
                            <p className="font-medium">{route.routeName}</p>
                            <p className="text-sm text-muted-foreground">
                              {route.routeNumber} • {route.description}
                            </p>
                          </div>
                          <div className="flex items-center space-x-4 text-sm">
                            <div className="flex items-center text-muted-foreground">
                              <IndianRupee className="h-3 w-3 mr-1" />
                              {route.fare}
                            </div>
                            <div className="flex items-center text-muted-foreground">
                              <Clock className="h-3 w-3 mr-1" />
                              {route.estimatedDuration}m
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Bus Stops Results */}
                {busStops && busStops.length > 0 && (
                  <div className="p-4">
                    <h3 className="font-semibold text-sm text-muted-foreground mb-3 flex items-center">
                      <MapPin className="h-4 w-4 mr-2" />
                      Bus Stops
                    </h3>
                    <div className="space-y-2">
                      {busStops.slice(0, 3).map((stop) => (
                        <motion.div
                          key={stop._id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="flex items-center p-3 hover:bg-muted/50 rounded-lg cursor-pointer transition-colors"
                        >
                          <MapPin className="h-4 w-4 mr-3 text-primary" />
                          <div>
                            <p className="font-medium">{stop.name}</p>
                            <p className="text-sm text-muted-foreground">
                              {stop.address}
                            </p>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {/* No Results */}
                {routes?.length === 0 && busStops?.length === 0 && (
                  <div className="p-8 text-center">
                    <Search className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                    <p className="text-muted-foreground">
                      No results found for "{searchTerm}"
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Overlay to close search results */}
      {showResults && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setShowResults(false)}
        />
      )}
    </div>
  );
}
