import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Clock, Users } from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";
import { useEffect } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function LiveMap() {
  const buses = useQuery(api.buses.getActiveBuses);
  const busStops = useQuery(api.busStops.getActiveBusStops);
  const [selectedStopId, setSelectedStopId] = useState<string>("");
  const [selectedBusId, setSelectedBusId] = useState<string>("");
  const [myLocation, setMyLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [sampleStop, setSampleStop] = useState<{ lat: number; lng: number } | null>(null);

  useEffect(() => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setMyLocation(coords);
        // place a demo bus stop ~200m NE of user
        const offsetLat = 0.0018; // ~200m
        const offsetLng = 0.0018; // ~200m
        setSampleStop({ lat: coords.lat + offsetLat, lng: coords.lng + offsetLng });
      },
      () => {
        // If permission denied or failed, keep null; map still renders
      },
      { enableHighAccuracy: true, timeout: 5000 }
    );
  }, []);

  const getCrowdColor = (level: string) => {
    switch (level) {
      case "low": return "bg-green-500";
      case "moderate": return "bg-yellow-500";
      case "high": return "bg-red-500";
      default: return "bg-gray-500";
    }
  };

  const getCrowdText = (level: string) => {
    switch (level) {
      case "low": return "Empty";
      case "moderate": return "Moderate";
      case "high": return "Crowded";
      default: return "Unknown";
    }
  };

  if (!buses) {
    return (
      <Card className="h-96">
        <CardContent className="flex items-center justify-center h-full">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between space-x-2">
            <div className="flex items-center space-x-2">
              <MapPin className="h-5 w-5 text-primary" />
              <span>Live Bus Tracking</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="hidden md:block text-sm text-muted-foreground">Bus Stop</div>
              <Select value={selectedStopId} onValueChange={setSelectedStopId}>
                <SelectTrigger className="w-[220px]">
                  <SelectValue placeholder="Select a bus stop" />
                </SelectTrigger>
                <SelectContent>
                  {(busStops || []).map((stop) => (
                    <SelectItem key={stop._id} value={stop._id}>
                      {stop.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Map placeholder - In a real app, this would be an interactive map */}
          <div className="relative bg-gradient-to-br from-blue-50 to-green-50 rounded-lg h-80 mb-6 overflow-hidden">
            <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
            <div className="absolute top-4 left-4 bg-white rounded-lg p-2 shadow-sm">
              <p className="text-sm font-medium text-muted-foreground">
                Chandigarh City Map
              </p>
            </div>

            {myLocation && (
              <div
                className="absolute"
                style={{
                  left: "12%",
                  top: "65%",
                }}
              >
                <div className="flex flex-col items-center">
                  <div className="w-3 h-3 bg-blue-600 rounded-full ring-4 ring-blue-600/20" />
                  <div className="mt-1 text-xs bg-white px-2 py-0.5 rounded shadow">You</div>
                </div>
              </div>
            )}

            {sampleStop && (
              <div
                className="absolute"
                style={{
                  left: "18%",
                  top: "58%",
                }}
              >
                <div className="flex flex-col items-center">
                  <div className="w-4 h-4 bg-white rounded-full border border-primary flex items-center justify-center shadow">
                    <MapPin className="h-3 w-3 text-primary" />
                  </div>
                  <div className="mt-1 text-xs bg-white px-2 py-0.5 rounded shadow">Bus Stop</div>
                </div>
              </div>
            )}

            {buses.map((bus, index) => {
              const isSelected = selectedBusId === (bus._id as unknown as string);
              const isNearby =
                !!selectedStopId && bus.nextStopId === (selectedStopId as any);

              return (
                <motion.div
                  key={bus._id}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className="absolute"
                  style={{
                    left: `${20 + index * 25}%`,
                    top: `${30 + index * 15}%`,
                  }}
                >
                  <div className="relative">
                    <div
                      className={[
                        "rounded-full flex items-center justify-center text-white text-sm font-bold shadow-lg",
                        isSelected
                          ? "w-10 h-10 bg-accent ring-4 ring-accent/30 animate-bounce"
                          : isNearby
                          ? "w-9 h-9 bg-primary ring-2 ring-primary/30"
                          : "w-8 h-8 bg-primary/80",
                      ].join(" ")}
                    >
                      🚌🇮🇳
                    </div>
                    <div
                      className={`absolute -top-1 -right-1 w-3 h-3 rounded-full ${getCrowdColor(
                        bus.crowdLevel
                      )}`}
                    />
                    <div className="absolute top-10 left-1/2 transform -translate-x-1/2 bg-white rounded px-2 py-1 shadow-sm text-xs whitespace-nowrap">
                      {bus.busNumber}
                      {isSelected && <span className="ml-1 text-[10px] text-accent">• Selected</span>}
                      {!isSelected && isNearby && (
                        <span className="ml-1 text-[10px] text-primary">• Nearby</span>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Bus list */}
          <div className="space-y-3">
            <h3 className="font-semibold text-lg">Active Buses</h3>
            {buses.map((bus) => {
              const etaMinutes =
                bus.estimatedArrival &&
                selectedStopId &&
                bus.nextStopId === selectedStopId
                  ? Math.max(0, Math.round((bus.estimatedArrival - Date.now()) / (1000 * 60)))
                  : null;

              const isSelected = selectedBusId === (bus._id as unknown as string);
              const isNearby =
                !!selectedStopId && bus.nextStopId === (selectedStopId as any);

              return (
                <motion.div
                  key={bus._id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={[
                    "flex items-center justify-between p-4 rounded-lg cursor-pointer transition",
                    isSelected ? "bg-accent/10 border border-accent/40" : "bg-muted/50",
                    !isSelected && isNearby ? "ring-1 ring-primary/30" : "",
                  ].join(" ")}
                  onClick={() => setSelectedBusId(bus._id as unknown as string)}
                >
                  <div className="flex items-center space-x-4">
                    <div
                      className={[
                        "w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold",
                        isSelected ? "bg-accent" : "bg-primary",
                      ].join(" ")}
                    >
                      🚌🇮🇳
                    </div>
                    <div>
                      <p className="font-semibold">{bus.busNumber}</p>
                      <p className="text-sm text-muted-foreground">
                        {bus.route?.routeName}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-6">
                    {/* Fare */}
                    {typeof bus.route?.fare === "number" && (
                      <div className="flex items-center text-sm text-muted-foreground">
                        <span className="mr-1">₹</span>
                        {bus.route.fare}
                      </div>
                    )}
                    {/* Capacity */}
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Users className="h-4 w-4 mr-1" />
                      Cap: {bus.capacity}
                    </div>
                    {/* Crowd */}
                    <Badge
                      variant="secondary"
                      className={`${getCrowdColor(bus.crowdLevel)} text-white`}
                    >
                      <Users className="h-3 w-3 mr-1" />
                      {getCrowdText(bus.crowdLevel)}
                    </Badge>
                    {/* ETA (only when next stop matches selection) */}
                    {etaMinutes !== null && (
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Clock className="h-4 w-4 mr-1" />
                        {etaMinutes} min
                      </div>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}