import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useNavigate } from "react-router";
import { 
  MapPin, 
  Clock, 
  Users, 
  AlertTriangle, 
  Megaphone, 
  Shield,
  ArrowRight,
  CheckCircle
} from "lucide-react";
import { useState, useEffect } from "react";

export default function Landing() {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  // Add one-time moving bus animation
  const [showBusAnim, setShowBusAnim] = useState(true);
  useEffect(() => {
    const timer = setTimeout(() => setShowBusAnim(false), 3500);
    return () => clearTimeout(timer);
  }, []);

  const features = [
    {
      icon: <MapPin className="h-8 w-8" />,
      title: "Live Bus Tracking",
      description: "Track buses in real-time with GPS-based location updates and estimated arrival times.",
    },
    {
      icon: <Clock className="h-8 w-8" />,
      title: "Route Planning",
      description: "Find the best routes with multiple options - fastest, least crowded, or shortest distance.",
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: "Crowd Indicators",
      description: "See real-time crowd levels with visual indicators to plan your journey better.",
    },
    {
      icon: <AlertTriangle className="h-8 w-8" />,
      title: "SOS Emergency",
      description: "One-tap emergency alerts to the nearest control center with your location.",
    },
    {
      icon: <Megaphone className="h-8 w-8" />,
      title: "Live Updates",
      description: "Get official announcements about delays, route changes, and service updates.",
    },
    {
      icon: <Shield className="h-8 w-8" />,
      title: "Secure & Reliable",
      description: "Government-backed secure platform with verified information and data protection.",
    },
  ];

  const stats = [
    { number: "50+", label: "Active Buses" },
    { number: "100+", label: "Bus Stops" },
    { number: "15+", label: "Routes" },
    { number: "24/7", label: "Live Tracking" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="bg-white border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">🚌🇮🇳</span>
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight text-primary">
                  Yaatri Sarthak
                </h1>
                <p className="text-xs text-muted-foreground">
                  Yaatri Sarthak
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => navigate("/auth")}
              >
                Sign In
              </Button>
              <Button
                onClick={() => navigate(isAuthenticated ? "/dashboard" : "/auth")}
                className="bg-primary hover:bg-primary/90"
              >
                {isAuthenticated ? "Dashboard" : "Get Started"}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-accent/5">
        {showBusAnim && (
          <motion.div
            initial={{ x: "-20vw", opacity: 0 }}
            animate={{ x: "110vw", opacity: 1 }}
            transition={{ duration: 3, ease: "easeInOut" }}
            className="pointer-events-none fixed top-24 left-0 z-40"
            onAnimationComplete={() => setShowBusAnim(false)}
          >
            <div className="text-4xl drop-shadow-md">🚌🇮🇳</div>
          </motion.div>
        )}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex justify-center mb-8">
                <div className="w-20 h-20 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center shadow-lg">
                  <span className="text-white font-bold text-3xl">🚌🇮🇳</span>
                </div>
              </div>
              
              <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-primary mb-6">
                Real-time Public
                <br />
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  Transport Tracking
                </span>
              </h1>
              
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
                Track buses live, plan your routes efficiently, and stay connected with 
                real-time updates from the Yaatri Sarthak transport system.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  onClick={() => navigate(isAuthenticated ? "/dashboard" : "/auth")}
                  className="bg-primary hover:bg-primary/90 text-lg px-8 py-6"
                >
                  {isAuthenticated ? "Go to Dashboard" : "Start Tracking"}
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => navigate("/routes")}
                  className="text-lg px-8 py-6"
                >
                  View Routes
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">
                  {stat.number}
                </div>
                <div className="text-muted-foreground font-medium">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-primary mb-4">
              Everything You Need for Smart Travel
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Comprehensive features designed to make public transport more accessible, 
              reliable, and user-friendly for everyone.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow duration-300">
                  <CardContent className="p-8">
                    <div className="text-primary mb-4">
                      {feature.icon}
                    </div>
                    <h3 className="text-xl font-semibold mb-3 text-primary">
                      {feature.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Government Section */}
      <section className="py-16 bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 bg-white/10 rounded-xl flex items-center justify-center">
                <Shield className="h-8 w-8" />
              </div>
            </div>
            
            <h2 className="text-3xl font-bold mb-4">
              Trusted by Yaatri Sarthak
            </h2>
            <p className="text-xl text-white/80 mb-8 max-w-2xl mx-auto">
              Official government platform ensuring data security, reliability, 
              and accurate real-time information for all citizens.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5" />
                <span>Verified Information</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5" />
                <span>Secure Platform</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5" />
                <span>24/7 Support</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-br from-accent/10 to-primary/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-primary mb-6">
              Ready to Start Your Smart Journey?
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Join thousands of commuters who trust Punjab Transport for their daily travel needs.
            </p>
            <Button
              size="lg"
              onClick={() => navigate(isAuthenticated ? "/dashboard" : "/auth")}
              className="bg-primary hover:bg-primary/90 text-lg px-12 py-6"
            >
              {isAuthenticated ? "Go to Dashboard" : "Get Started Now"}
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex justify-center items-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">🚌</span>
              </div>
              <span className="text-xl font-bold">Yaatri Sarthak</span>
            </div>
            <p className="text-white/80 mb-4">
              Yaatri Sarthak
            </p>
            <p className="text-white/60 text-sm">
              © 2024 Yaatri Sarthak. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}