import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Navigate } from "react-router";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import Navbar from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  Bus, 
  AlertTriangle, 
  UserPlus, 
  Settings,
  CheckCircle,
  Clock,
  Megaphone
} from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";

export default function Admin() {
  const { isLoading, isAuthenticated, user } = useAuth();
  const [addDriverOpen, setAddDriverOpen] = useState(false);
  const [updateOpen, setUpdateOpen] = useState(false);
  const [driverPhone, setDriverPhone] = useState("");
  const [driverName, setDriverName] = useState("");
  const [updateTitle, setUpdateTitle] = useState("");
  const [updateContent, setUpdateContent] = useState("");
  const [updatePriority, setUpdatePriority] = useState<"low" | "medium" | "high">("medium");

  const overview = useQuery(api.admin.adminOverview);
  const drivers = useQuery(api.admin.listDrivers);
  const alerts = useQuery(api.admin.listAlerts);
  const buses = useQuery(api.buses.getActiveBuses);

  const addDriver = useMutation(api.admin.addDriverByPhone);
  const assignDriver = useMutation(api.admin.assignDriverToBus);
  const resolveAlert = useMutation(api.emergencyAlerts.resolveEmergencyAlert);
  const createUpdate = useMutation(api.admin.createCommunityUpdateQuick);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated || (user?.role !== "admin" && user?.role !== "authority")) {
    return <Navigate to="/auth" replace />;
  }

  const handleAddDriver = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!driverPhone.trim()) {
      toast.error("Phone number is required");
      return;
    }

    try {
      await addDriver({ 
        phone: driverPhone.trim(), 
        name: driverName.trim() || undefined 
      });
      toast.success("Driver added successfully");
      setAddDriverOpen(false);
      setDriverPhone("");
      setDriverName("");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to add driver");
    }
  };

  const handleAssignDriver = async (driverUserId: string, busId: string) => {
    try {
      await assignDriver({ 
        driverUserId: driverUserId as any, 
        busId: busId as any 
      });
      toast.success("Driver assigned to bus");
    } catch (error) {
      toast.error("Failed to assign driver");
    }
  };

  const handleResolveAlert = async (alertId: string) => {
    try {
      await resolveAlert({ alertId: alertId as any });
      toast.success("Alert resolved");
    } catch (error) {
      toast.error("Failed to resolve alert");
    }
  };

  const handleCreateUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!updateTitle.trim() || !updateContent.trim()) {
      toast.error("Title and content are required");
      return;
    }

    try {
      await createUpdate({
        title: updateTitle.trim(),
        content: updateContent.trim(),
        priority: updatePriority,
      });
      toast.success("Update published");
      setUpdateOpen(false);
      setUpdateTitle("");
      setUpdateContent("");
      setUpdatePriority("medium");
    } catch (error) {
      toast.error("Failed to create update");
    }
  };

  const formatTimeAgo = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(minutes / 60);
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return "Just now";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/10">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-2">
            Admin Dashboard
          </h1>
          <p className="text-muted-foreground text-lg">
            Manage drivers, buses, and monitor system operations
          </p>
        </motion.div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Bus className="h-8 w-8 text-primary" />
                <div>
                  <p className="text-2xl font-bold">{overview?.totalBuses || 0}</p>
                  <p className="text-sm text-muted-foreground">Total Buses</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-8 w-8 text-green-600" />
                <div>
                  <p className="text-2xl font-bold">{overview?.activeBuses || 0}</p>
                  <p className="text-sm text-muted-foreground">Active Buses</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-8 w-8 text-red-600" />
                <div>
                  <p className="text-2xl font-bold">{overview?.unresolvedAlerts || 0}</p>
                  <p className="text-sm text-muted-foreground">Active Alerts</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Users className="h-8 w-8 text-blue-600" />
                <div>
                  <p className="text-2xl font-bold">{overview?.driversCount || 0}</p>
                  <p className="text-sm text-muted-foreground">Drivers</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Drivers Management */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  <Users className="h-5 w-5" />
                  <span>Drivers</span>
                </CardTitle>
                <Dialog open={addDriverOpen} onOpenChange={setAddDriverOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <UserPlus className="h-4 w-4 mr-2" />
                      Add Driver
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Driver</DialogTitle>
                      <DialogDescription>
                        Add a driver by phone number. They can sign in using this number.
                      </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleAddDriver} className="space-y-4">
                      <Input
                        placeholder="Phone number (+91XXXXXXXXXX)"
                        value={driverPhone}
                        onChange={(e) => setDriverPhone(e.target.value)}
                        required
                      />
                      <Input
                        placeholder="Driver name (optional)"
                        value={driverName}
                        onChange={(e) => setDriverName(e.target.value)}
                      />
                      <div className="flex space-x-2">
                        <Button type="button" variant="outline" onClick={() => setAddDriverOpen(false)} className="flex-1">
                          Cancel
                        </Button>
                        <Button type="submit" className="flex-1">
                          Add Driver
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {drivers?.map((driver) => (
                  <div key={driver._id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="font-medium">{driver.name || "Unnamed Driver"}</p>
                        <p className="text-sm text-muted-foreground">{driver.phoneNumber}</p>
                      </div>
                      <Badge variant="secondary">Driver</Badge>
                    </div>
                    {driver.assignedBuses.length > 0 ? (
                      <div className="text-sm">
                        <p className="text-muted-foreground">Assigned to:</p>
                        {driver.assignedBuses.map((bus) => (
                          <p key={bus._id} className="font-medium">{bus.busNumber}</p>
                        ))}
                      </div>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <p className="text-sm text-muted-foreground">Not assigned</p>
                        <Select onValueChange={(busId) => handleAssignDriver(driver._id, busId)}>
                          <SelectTrigger className="w-32">
                            <SelectValue placeholder="Assign" />
                          </SelectTrigger>
                          <SelectContent>
                            {buses?.filter(bus => !bus.driverUserId).map((bus) => (
                              <SelectItem key={bus._id} value={bus._id}>
                                {bus.busNumber}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Emergency Alerts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <AlertTriangle className="h-5 w-5 text-red-600" />
                <span>Active Emergency Alerts</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {alerts?.map((alert) => (
                  <div key={alert._id} className="border rounded-lg p-4 border-red-200 bg-red-50">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <Badge variant="destructive" className="mb-2">
                          {alert.emergencyType}
                        </Badge>
                        <p className="text-sm font-medium">
                          {alert.user?.name || "Anonymous User"}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {formatTimeAgo(alert._creationTime)}
                        </p>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => handleResolveAlert(alert._id)}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        Resolve
                      </Button>
                    </div>
                    {alert.description && (
                      <p className="text-sm text-muted-foreground mb-2">
                        {alert.description}
                      </p>
                    )}
                    <p className="text-xs text-muted-foreground">
                      Location: {alert.latitude.toFixed(4)}, {alert.longitude.toFixed(4)}
                    </p>
                  </div>
                ))}
                {(!alerts || alerts.length === 0) && (
                  <p className="text-center text-muted-foreground py-8">
                    No active alerts
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Update */}
        <Card className="mt-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center space-x-2">
                <Megaphone className="h-5 w-5" />
                <span>Quick Community Update</span>
              </CardTitle>
              <Dialog open={updateOpen} onOpenChange={setUpdateOpen}>
                <DialogTrigger asChild>
                  <Button>Create Update</Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>Create Community Update</DialogTitle>
                    <DialogDescription>
                      Publish an official update for all users
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreateUpdate} className="space-y-4">
                    <Input
                      placeholder="Update title"
                      value={updateTitle}
                      onChange={(e) => setUpdateTitle(e.target.value)}
                      required
                    />
                    <Textarea
                      placeholder="Update content"
                      value={updateContent}
                      onChange={(e) => setUpdateContent(e.target.value)}
                      rows={4}
                      required
                    />
                    <Select value={updatePriority} onValueChange={(value: any) => setUpdatePriority(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low Priority</SelectItem>
                        <SelectItem value="medium">Medium Priority</SelectItem>
                        <SelectItem value="high">High Priority</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="flex space-x-2">
                      <Button type="button" variant="outline" onClick={() => setUpdateOpen(false)} className="flex-1">
                        Cancel
                      </Button>
                      <Button type="submit" className="flex-1">
                        Publish
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
        </Card>
      </main>
    </div>
  );
}
