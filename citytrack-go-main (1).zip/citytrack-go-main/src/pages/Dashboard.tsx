import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Navigate } from "react-router";
import Navbar from "@/components/Navbar";
import LiveMap from "@/components/LiveMap";
import SearchBar from "@/components/SearchBar";
import EmergencyButton from "@/components/EmergencyButton";
import CommunityUpdates from "@/components/CommunityUpdates";
import { motion } from "framer-motion";
import BuyTicket from "@/components/BuyTicket";

export default function Dashboard() {
  const { isLoading, isAuthenticated } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/auth" replace />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/10">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header Section */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-2">
            Real-time Public Transport
          </h1>
          <p className="text-muted-foreground text-lg">
            Track buses, plan routes, and stay updated with live information
          </p>
        </motion.div>

        {/* Search Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <SearchBar />
        </motion.div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Live Map - Takes up 2 columns on large screens */}
          <div className="lg:col-span-2">
            <LiveMap />
          </div>

          {/* Right column */}
          <div className="lg:col-span-1 space-y-8">
            {/* Buy Ticket Section */}
            <BuyTicket />
            {/* Community Updates */}
            <CommunityUpdates />
            {/* SOS button fixed below Live Updates */}
            <div className="flex justify-end">
              <EmergencyButton />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}