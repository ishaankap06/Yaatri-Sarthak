import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Navigate } from "react-router";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import Navbar from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  Bus, 
  MapPin, 
  Users, 
  Clock,
  Play,
  Square,
  AlertTriangle,
  Navigation
} from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import type { Id } from "@/convex/_generated/dataModel";

export default function Driver() {
  const { isLoading, isAuthenticated, user } = useAuth();
  const [selectedBusId, setSelectedBusId] = useState<string>("");
  const [isOnShift, setIsOnShift] = useState(false);
  const [crowdLevel, setCrowdLevel] = useState<"low" | "moderate" | "high">("low");
  const [nextStopId, setNextStopId] = useState<string>("");
  const [etaMinutes, setEtaMinutes] = useState<string>("");
  const [locationEnabled, setLocationEnabled] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<{lat: number, lng: number} | null>(null);

  const profile = useQuery(api.driver.myProfile);
  const assignedBuses = useQuery(api.driver.myAssignedBuses);
  const busStops = useQuery(api.busStops.getActiveBusStops);

  const startShift = useMutation(api.driver.startShift);
  const endShift = useMutation(api.driver.endShift);
  const updateTelemetry = useMutation(api.driver.updateBusTelemetry);

  const selectedBus = assignedBuses?.find(bus => bus._id === selectedBusId);

  useEffect(() => {
    if (assignedBuses && assignedBuses.length > 0 && !selectedBusId) {
      setSelectedBusId(assignedBuses[0]._id);
    }
  }, [assignedBuses, selectedBusId]);

  useEffect(() => {
    let watchId: number | null = null;

    if (locationEnabled && isOnShift && selectedBusId) {
      if ("geolocation" in navigator) {
        watchId = navigator.geolocation.watchPosition(
          (position) => {
            const { latitude, longitude } = position.coords;
            setCurrentLocation({ lat: latitude, lng: longitude });
            
            // Update bus location every 10 seconds
            updateTelemetry({
              busId: selectedBusId as any,
              latitude,
              longitude,
              crowdLevel,
              // Cast to Convex Id type to satisfy strict typing
              nextStopId: (nextStopId || undefined) as Id<"busStops"> | undefined,
              estimatedArrival: etaMinutes ? Date.now() + parseInt(etaMinutes) * 60 * 1000 : undefined,
            }).catch(error => {
              console.error("Failed to update telemetry:", error);
            });
          },
          (error) => {
            console.error("Geolocation error:", error);
            toast.error("Unable to get location. Please check permissions.");
            setLocationEnabled(false);
          },
          {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 5000,
          }
        );
      } else {
        toast.error("Geolocation is not supported by this browser");
        setLocationEnabled(false);
      }
    }

    return () => {
      if (watchId !== null) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [locationEnabled, isOnShift, selectedBusId, crowdLevel, nextStopId, etaMinutes, updateTelemetry]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated || !profile?.isDriver) {
    return <Navigate to="/auth" replace />;
  }

  const handleStartShift = async () => {
    if (!selectedBusId) {
      toast.error("Please select a bus first");
      return;
    }

    try {
      await startShift({ busId: selectedBusId as any });
      setIsOnShift(true);
      toast.success("Shift started");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to start shift");
    }
  };

  const handleEndShift = async () => {
    if (!selectedBusId) return;

    try {
      await endShift({ busId: selectedBusId as any });
      setIsOnShift(false);
      setLocationEnabled(false);
      toast.success("Shift ended");
    } catch (error) {
      toast.error("Failed to end shift");
    }
  };

  const handleLocationToggle = () => {
    if (!isOnShift) {
      toast.error("Please start your shift first");
      return;
    }

    if (!locationEnabled) {
      if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(
          () => {
            setLocationEnabled(true);
            toast.success("Location sharing enabled");
          },
          (error) => {
            toast.error("Location permission denied. Please enable location access.");
          }
        );
      } else {
        toast.error("Geolocation not supported");
      }
    } else {
      setLocationEnabled(false);
      toast.success("Location sharing disabled");
    }
  };

  const routeStops = selectedBus?.route?.stops || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/10">
      <Navbar />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-2">
            Driver Console
          </h1>
          <p className="text-muted-foreground text-lg">
            Welcome, {profile?.name || "Driver"}
          </p>
        </motion.div>

        {/* Safety Banner */}
        <Card className="mb-6 border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2 text-red-800">
              <AlertTriangle className="h-5 w-5" />
              <p className="text-sm font-medium">
                Safety First: In case of emergency, contact control center immediately at 112
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Bus Selection & Shift Controls */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Bus className="h-5 w-5" />
                <span>Assigned Buses</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {assignedBuses && assignedBuses.length > 0 ? (
                <>
                  <Select value={selectedBusId} onValueChange={setSelectedBusId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your bus" />
                    </SelectTrigger>
                    <SelectContent>
                      {assignedBuses.map((bus) => (
                        <SelectItem key={bus._id} value={bus._id}>
                          <div className="flex items-center space-x-2">
                            <span>{bus.busNumber}</span>
                            <Badge variant="secondary">{bus.route?.routeName}</Badge>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {selectedBus && (
                    <div className="border rounded-lg p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{selectedBus.busNumber}</span>
                        <Badge variant={selectedBus.status === "active" ? "default" : "secondary"}>
                          {selectedBus.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Route: {selectedBus.route?.routeName}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Capacity: {selectedBus.capacity} passengers
                      </p>
                    </div>
                  )}

                  <div className="flex space-x-2">
                    {!isOnShift ? (
                      <Button 
                        onClick={handleStartShift}
                        disabled={!selectedBusId}
                        className="flex-1"
                      >
                        <Play className="h-4 w-4 mr-2" />
                        Start Shift
                      </Button>
                    ) : (
                      <Button 
                        onClick={handleEndShift}
                        variant="destructive"
                        className="flex-1"
                      >
                        <Square className="h-4 w-4 mr-2" />
                        End Shift
                      </Button>
                    )}
                  </div>
                </>
              ) : (
                <div className="text-center py-8">
                  <Bus className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">
                    No buses assigned. Contact your administrator.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Location & Telemetry */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MapPin className="h-5 w-5" />
                <span>Location & Updates</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Live Location Sharing</span>
                <Button
                  onClick={handleLocationToggle}
                  variant={locationEnabled ? "default" : "outline"}
                  size="sm"
                  disabled={!isOnShift}
                >
                  <Navigation className="h-4 w-4 mr-2" />
                  {locationEnabled ? "Enabled" : "Enable"}
                </Button>
              </div>

              {currentLocation && (
                <div className="text-xs text-muted-foreground">
                  Current: {currentLocation.lat.toFixed(4)}, {currentLocation.lng.toFixed(4)}
                </div>
              )}

              <div>
                <label className="text-sm font-medium mb-2 block">Crowd Level</label>
                <Select value={crowdLevel} onValueChange={(value: any) => setCrowdLevel(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 rounded-full bg-green-500"></div>
                        <span>Low</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="moderate">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                        <span>Moderate</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="high">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 rounded-full bg-red-500"></div>
                        <span>High</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Next Stop</label>
                <Select value={nextStopId} onValueChange={setNextStopId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select next stop" />
                  </SelectTrigger>
                  <SelectContent>
                    {busStops?.map((stop) => (
                      <SelectItem key={stop._id} value={stop._id}>
                        {stop.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">ETA (minutes)</label>
                <Input
                  type="number"
                  placeholder="5"
                  value={etaMinutes}
                  onChange={(e) => setEtaMinutes(e.target.value)}
                  min="1"
                  max="60"
                />
              </div>

              {isOnShift && (
                <div className="flex items-center space-x-2 text-green-600">
                  <div className="w-2 h-2 rounded-full bg-green-600 animate-pulse"></div>
                  <span className="text-sm">On Shift</span>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}